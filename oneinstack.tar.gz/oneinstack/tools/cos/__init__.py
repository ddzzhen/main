#!/usr/bin/env python
# coding=utf-8

from qcloud_cos import CosClient
from qcloud_cos import UploadFileRequest
from qcloud_cos import CreateFolderRequest
from qcloud_cos import DelFileRequest
from qcloud_cos import DelFolderRequest
from qcloud_cos import ListFolderRequest
import threadpool
